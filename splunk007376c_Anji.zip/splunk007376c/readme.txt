Splunk Questions DOC:  https://goo.gl/p458Ph


Feel free to download, answer and re-upload on HackerEarth platform.


Any additional material can be kept in same folder and ensure that you archive everything and upload one single ZIP file.
